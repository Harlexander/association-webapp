import React from 'react'
import HeroCarousel from '../Carousel/HeroCarousel'

const HeroSection = () => {
  return (
    <HeroCarousel/>
  )
}

export default HeroSection
